Read Me :

How to Run:

We can create runnable jar ( by mvn clean install ) or importing in IDE and running the spring boot class

Application will run in 9001 Port
Rest Service Url will be : http://localhost:9001/rabo/customer/statement/processor 
Method: Post
Body : 	set content type as : multipart/form-data
		field name as : Records
		choose file as : File to test 


When running application as jar - will create log & multipart file (request file ) in same the folder for reference.


How to Test Junit:

- Need to run as Junit5
- Before run the test case , recommand to  run & test once the application are working as expected in IDE will good. 