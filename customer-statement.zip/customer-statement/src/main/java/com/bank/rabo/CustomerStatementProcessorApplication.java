package com.bank.rabo;

import com.bank.rabo.models.RaboResponseBuilder;
import com.bank.rabo.models.Record;
import com.bank.rabo.processor.CsvFileProcessor;
import com.bank.rabo.processor.XmlFileProcessor;
import com.bank.rabo.validator.RecordValidator;
import com.bank.rabo.validator.StatementValidator;
import com.opencsv.CSVReader;
import com.opencsv.bean.CsvToBean;
import com.opencsv.bean.HeaderColumnNameTranslateMappingStrategy;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.core.io.ClassPathResource;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

@SpringBootApplication
public class CustomerStatementProcessorApplication {

	public static void main(String[] args) {
		SpringApplication.run(CustomerStatementProcessorApplication.class, args);
	}

	@Bean
	public XmlFileProcessor getXmlProcessor()
	{
		return new XmlFileProcessor();
	}

	@Bean
	public CsvFileProcessor getCsvProcessor()
	{
		return new CsvFileProcessor();
	}

	@Bean
	public StatementValidator getStatementValidator()
	{
		return new StatementValidator();
	}


	@Bean
	public RaboResponseBuilder getRaboResponseBuilder()
	{
		return new RaboResponseBuilder();
	}

	@Bean
	public CsvToBean getCsvBean()
	{
		return new CsvToBean();
	}

	@Bean
	HeaderColumnNameTranslateMappingStrategy<Record> getMappingStrategyMap()
	{
		return new HeaderColumnNameTranslateMappingStrategy<Record>();
	}

	@Bean
	RecordValidator getRecordValidator()
	{
		return new RecordValidator();
	}

}
