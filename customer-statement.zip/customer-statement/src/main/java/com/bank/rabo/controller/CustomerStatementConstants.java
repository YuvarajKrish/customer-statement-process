package com.bank.rabo.controller;

public class CustomerStatementConstants {

    public static final String RABO = "/rabo";
    public static final String CUSTOMER = "/customer";
    public static final String STATEMENT = "/statement";
    public static final String PROCESSOR = "/processor";

    public static final String XML_FILE = ".xml";
    public static final String CSV_FILE = ".csv";

}
