package com.bank.rabo.controller;

import com.bank.rabo.constant.CustomerStatementConstants;
import com.bank.rabo.delegate.StatementProcessDelegation;
import com.bank.rabo.models.RaboResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@RestController
@RequestMapping(CustomerStatementConstants.RABO + CustomerStatementConstants.CUSTOMER + CustomerStatementConstants.STATEMENT)
public class StatementProcessorController {


    Logger logger = LoggerFactory.getLogger(StatementProcessorController.class);

    @Autowired
    StatementProcessDelegation delegation;

    @PostMapping(value = CustomerStatementConstants.PROCESSOR, consumes = {MediaType.MULTIPART_FORM_DATA_VALUE}, produces = {MediaType.APPLICATION_JSON_VALUE})
    public ResponseEntity<List<RaboResponse>> processMultiFileRequest(@RequestParam("${customer.file.request.keyValue}") MultipartFile[] files) {
        logger.info("Controller: processMultiFileRequest() : Starts ; Files Count: {}" , files.length);
        List<RaboResponse> response = new ArrayList<>();

        Arrays.asList(files).stream().map(file -> delegation.processMultiFile(file)).forEach(response::addAll);

        logger.info("Controller: processMultiFileRequest() : Ends");
        return ResponseEntity.ok().body(response);
    }


}
