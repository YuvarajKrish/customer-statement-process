package com.bank.rabo.delegate;


import com.bank.rabo.exception.InvalidFileStructure;
import com.bank.rabo.models.RaboResponse;
import com.bank.rabo.service.CustomerStatementService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

@Component
public class StatementProcessDelegation {

    Logger logger = LoggerFactory.getLogger(StatementProcessDelegation.class);
    @Autowired
    CustomerStatementService service;
    @Value("${customer.error.message.invalidFile}")
    private String invalidFile;

    public List<RaboResponse> processMultiFile(MultipartFile mfile) {
        logger.info("Delegation: processMultiFile(): Starts");
        return service.processFile(multipartToFile(mfile));
    }

     File multipartToFile(MultipartFile mfile)  {

        File convFile = new File(mfile.getOriginalFilename());
      try{  convFile.createNewFile();
          FileOutputStream fos = new FileOutputStream(convFile);
          fos.write(mfile.getBytes());
          fos.close();
      }catch (Exception e)
      {
          logger.error(e.getMessage());
          throw new InvalidFileStructure(invalidFile);
      }

        return convFile;
    }

}
