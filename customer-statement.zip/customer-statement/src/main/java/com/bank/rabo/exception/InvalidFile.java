package com.bank.rabo.exception;

public class InvalidFile extends RuntimeException {

    public InvalidFile(String reference) {
        super(reference);
    }
}
