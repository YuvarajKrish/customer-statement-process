package com.bank.rabo.exception;

public  class InvalidFileStructure extends  RuntimeException {

    public InvalidFileStructure(String reference)
    {
        super(reference);
    }
}
