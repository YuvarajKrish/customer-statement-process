package com.bank.rabo.exception;

public class RecordNotValid extends  RuntimeException {

    public  RecordNotValid(String reference)
    {
        super(reference);
    }
}
