package com.bank.rabo.models;

public class RaboResponse {

    Record record;
    String errorReason;

    public Record getRecord() {
        return record;
    }

    public void setRecord(Record record) {
        this.record = record;
    }

    public String getErrorReason() {
        return errorReason;
    }

    public void setErrorReason(String errorReason) {
        this.errorReason = errorReason;
    }

    public RaboResponse(Record record, String reasonForFailed) {
        this.record = record;
        this.errorReason = reasonForFailed;
    }
}
