package com.bank.rabo.models;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

@Component
public class RaboResponseBuilder {

    @Value("${customer.error.code.duplicate}")
    private String duplicate;

    @Value("${customer.error.code.invalidBalance}")
    private String balance;


    public List<RaboResponse> getDuplicateRaboResponse(List<Record> duplicateTransaction) {
        return duplicateTransaction.stream().map(a -> new RaboResponse(a, duplicate)).collect(Collectors.toList());
    }

    public List<RaboResponse> getInvalidBalanceRaboResponse(List<Record> invalidBalance) {
        return invalidBalance.stream().map(a -> new RaboResponse(a, balance)).collect(Collectors.toList());
    }

}
