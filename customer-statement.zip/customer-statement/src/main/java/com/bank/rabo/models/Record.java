package com.bank.rabo.models;


import javax.xml.bind.annotation.*;
import java.math.BigDecimal;

/**
 * <p>Java class for anonymous complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="accountNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="description" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="startBalance" type="{http://www.w3.org/2001/XMLSchema}decimal"/>
 *         &lt;element name="mutation" type="{http://www.w3.org/2001/XMLSchema}decimal"/>
 *         &lt;element name="endBalance" type="{http://www.w3.org/2001/XMLSchema}decimal"/>
 *       &lt;/sequence>
 *       &lt;attribute name="reference" use="required" type="{http://www.w3.org/2001/XMLSchema}unsignedInt" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
        "accountNumber",
        "description",
        "startBalance",
        "mutation",
        "endBalance"
})
public class Record {


    @XmlElement(required = true)
    protected String accountNumber;
    @XmlElement(required = true)
    protected String description;
    @XmlElement(required = true)
    protected BigDecimal startBalance;
    @XmlElement(required = true)
    protected BigDecimal mutation;
    @XmlElement(required = true)
    protected BigDecimal endBalance;
    @XmlAttribute(name = "reference", required = true)
    @XmlSchemaType(name = "unsignedInt")
    protected long reference;

    /**
     * Gets the value of the accountNumber property.
     *
     * @return possible object is
     * {@link String }
     */
    public String getAccountNumber() {
        return accountNumber;
    }

    /**
     * Sets the value of the accountNumber property.
     *
     * @param value allowed object is
     *              {@link String }
     */
    public void setAccountNumber(String value) {
        this.accountNumber = value;
    }

    /**
     * Gets the value of the description property.
     *
     * @return possible object is
     * {@link String }
     */
    public String getDescription() {
        return description;
    }

    /**
     * Sets the value of the description property.
     *
     * @param value allowed object is
     *              {@link String }
     */
    public void setDescription(String value) {
        this.description = value;
    }

    /**
     * Gets the value of the startBalance property.
     *
     * @return possible object is
     * {@link BigDecimal }
     */
    public BigDecimal getStartBalance() {
        return startBalance;
    }

    /**
     * Sets the value of the startBalance property.
     *
     * @param value allowed object is
     *              {@link BigDecimal }
     */
    public void setStartBalance(BigDecimal value) {
        this.startBalance = value;
    }

    /**
     * Gets the value of the mutation property.
     *
     * @return possible object is
     * {@link BigDecimal }
     */
    public BigDecimal getMutation() {
        return mutation;
    }

    /**
     * Sets the value of the mutation property.
     *
     * @param value allowed object is
     *              {@link BigDecimal }
     */
    public void setMutation(BigDecimal value) {
        this.mutation = value;
    }

    /**
     * Gets the value of the endBalance property.
     *
     * @return possible object is
     * {@link BigDecimal }
     */
    public BigDecimal getEndBalance() {
        return endBalance;
    }

    /**
     * Sets the value of the endBalance property.
     *
     * @param value allowed object is
     *              {@link BigDecimal }
     */
    public void setEndBalance(BigDecimal value) {
        this.endBalance = value;
    }

    /**
     * Gets the value of the reference property.
     */
    public long getReference() {
        return reference;
    }

    /**
     * Sets the value of the reference property.
     */
    public void setReference(long value) {
        this.reference = value;
    }

    public Record() {

    }


    @Override
    public String toString() {
        return "Record [reference=" + reference + ", accountNumber=" + accountNumber + ", transactionDesc=" + description
                + ", startBalance=" + startBalance + ", mutation=" + mutation + ", endBalance=" + endBalance + "]";
    }

}
