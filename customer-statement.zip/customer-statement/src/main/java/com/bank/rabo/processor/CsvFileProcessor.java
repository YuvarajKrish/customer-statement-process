package com.bank.rabo.processor;

import com.bank.rabo.exception.InvalidFileStructure;
import com.bank.rabo.models.Record;
import com.opencsv.CSVReader;
import com.opencsv.bean.CsvToBean;
import com.opencsv.bean.HeaderColumnNameTranslateMappingStrategy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.FileReader;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class CsvFileProcessor implements FileProcessor {

    Logger logger = LoggerFactory.getLogger(CsvFileProcessor.class);

    @SuppressWarnings("rawtypes")
    @Autowired
    CsvToBean csvToBean;

    @Autowired
    HeaderColumnNameTranslateMappingStrategy<Record> strategy;

    //Since In CSV file Header having space in the name column,
    //loading the property as Map is getting issues (as a temp solution loading it as normal properties)

    @Value("${customer.csv.file.header.Reference}")
    private String referenceHeader;
    @Value("${customer.csv.file.header.AccountNumber}")
    private String accountNumberHeader;
    @Value("${customer.csv.file.header.Description}")
    private String descriptionHeader;
    @Value("${customer.csv.file.header.StartBalance}")
    private String startBalanceHeader;
    @Value("${customer.csv.file.header.Mutation}")
    private String endBalanceHeader;
    @Value("${customer.csv.file.header.EndBalance}")
    private String mutationHeader;

    @Value("${customer.csv.model.field.reference}")
    private String referenceField;
    @Value("${customer.csv.model.field.accountNumber}")
    private String accountNumberField;
    @Value("${customer.csv.model.field.Description}")
    private String descriptionField;
    @Value("${customer.csv.model.field.startBalance}")
    private String startBalanceField;
    @Value("${customer.csv.model.field.mutation}")
    private String endBalanceField;
    @Value("${customer.csv.model.field.endBalance}")
    private String mutationField;

    @Value("${customer.error.message.invalidFile}")
    private String invalidFile;

    @Override
    public List<Record> processFile(File file) {


        logger.info("processCustomerStatement() : Method Entry:");
        List<Record> list = null;

        try {

            csvToBean.setMappingStrategy(getMappingStrategy());
            csvToBean.setCsvReader(new CSVReader(new FileReader(file)));
            list = csvToBean.parse();

            logger.debug("Parsed Csv List Records :{}",  list);

        } catch (Exception e) {
            logger.error("Exception in Parsed while parsing the Csv file :{}",  e.getMessage());
            throw new InvalidFileStructure(invalidFile);
        }

        logger.info("processCustomerStatement() : Method Exist :");
        return list;

    }

    public Map<String, String> getMappingBean() {
        Map<String, String> mapping = new HashMap<>();

        mapping.put(referenceHeader, referenceField);
        mapping.put(accountNumberHeader, accountNumberField);
        mapping.put(descriptionHeader, descriptionField);
        mapping.put(startBalanceHeader, startBalanceField);
        mapping.put(mutationHeader, mutationField);
        mapping.put(endBalanceHeader, endBalanceField);


        return mapping;
    }

    HeaderColumnNameTranslateMappingStrategy<Record> getMappingStrategy() {
        strategy.setType(Record.class);
        strategy.setColumnMapping(getMappingBean());
        return strategy;
    }
}
