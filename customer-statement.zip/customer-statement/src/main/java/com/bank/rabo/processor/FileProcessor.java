package com.bank.rabo.processor;

import com.bank.rabo.models.Record;

import java.io.File;
import java.util.List;

public interface FileProcessor {

    public List<Record> processFile(File file);
}
