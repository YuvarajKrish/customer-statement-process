package com.bank.rabo.processor;

import com.bank.rabo.exception.InvalidFileStructure;
import com.bank.rabo.models.Record;
import com.bank.rabo.models.Records;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;
import java.io.File;
import java.util.List;

@Component
public class XmlFileProcessor implements FileProcessor {

    Logger logger = LoggerFactory.getLogger(XmlFileProcessor.class);

    @Value("${customer.error.message.invalidFile}")
    private String invalidFile;

    @Override
    public List<Record> processFile(File file) {


        logger.info("processCustomerStatement() : Method Entry");

        List<Record> recordsList = null;
        try {

            JAXBContext jaxbContext = JAXBContext.newInstance(Records.class);
            Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
            Records que = (Records) jaxbUnmarshaller.unmarshal(file);
            recordsList = que.getRecord();
            logger.debug("Parsed Xml List Records :" + recordsList);

        } catch (Exception e) {
            logger.error("processCustomerStatement() : Exception while parsing the xml file :{}" , e.getMessage());
            throw new InvalidFileStructure(invalidFile);
        }

        logger.info("processCustomerStatement() : Method Exist");

        return recordsList;
    }
}
