package com.bank.rabo.service;

import com.bank.rabo.controller.CustomerStatementConstants;
import com.bank.rabo.delegate.StatementProcessDelegation;
import com.bank.rabo.exception.InvalidFileStructure;
import com.bank.rabo.models.RaboResponse;
import com.bank.rabo.models.Record;
import com.bank.rabo.processor.CsvFileProcessor;
import com.bank.rabo.processor.XmlFileProcessor;
import com.bank.rabo.validator.RecordValidator;
import com.bank.rabo.validator.StatementValidator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.util.List;

@Service
public class CustomerStatementService {

    Logger logger = LoggerFactory.getLogger(CustomerStatementService.class);
    @Autowired
    XmlFileProcessor xmlFileProcessor;

    @Autowired
    CsvFileProcessor csvFileProcessor;

    @Autowired
    StatementValidator statementValidator;

    @Autowired
    RecordValidator recordValidator;


    @Value("${customer.error.message.invalidFile}")
    private String invalidFile;


    public List<RaboResponse> processFile(File mfile) {


        logger.info("Service: ProcessFile: Starts");
        List<Record> recordList;

        if (mfile.getName().contains(CustomerStatementConstants.XML_FILE)) {
            recordList = xmlFileProcessor.processFile(mfile);
        } else if (mfile.getName().contains(CustomerStatementConstants.CSV_FILE)) {
            recordList = csvFileProcessor.processFile(mfile);
        } else {
            throw new InvalidFileStructure(invalidFile);
        }
        logger.info("Service: ProcessFile: RecordList:" + recordList);

        recordList.stream().forEach(a -> recordValidator.validateRecord(a));


        return statementValidator.customerStatementProcessing(recordList);
    }
}
