package com.bank.rabo.validator;


import com.bank.rabo.exception.RecordNotValid;
import com.bank.rabo.models.Record;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;


import javax.validation.Valid;
import java.math.BigDecimal;

@Component
public class RecordValidator {

    Logger logger = LoggerFactory.getLogger(RecordValidator.class);

    @Value("${customer.error.message.invalidAccNt}")
    String refNotAccNt;

    @Value("${customer.error.message.invalidRef}")
    String refNotValid;

    @Value("${customer.error.message.invalidMutation}")
    String invalidMutation;

    public boolean validateRecord(@Valid Record record) {
        logger.info("Validate Record:{}" , record);

        if (StringUtils.isEmpty(record.getAccountNumber())) {
            throw new RecordNotValid(refNotAccNt + record.getReference());
        } else if (record.getReference() == 0) {
            throw new RecordNotValid(refNotValid + record.getReference());
        } else if (record.getMutation().equals(BigDecimal.ZERO)) {
            throw new RecordNotValid(invalidMutation + record.getReference());
        }

        return true;
    }


}
