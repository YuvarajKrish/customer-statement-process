package com.bank.rabo.validator;

import java.util.List;
import java.util.stream.Collectors;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import com.bank.rabo.models.RaboResponse;
import com.bank.rabo.models.RaboResponseBuilder;
import com.bank.rabo.models.Record;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.annotation.Validated;


/**
 * Class to validate the Business logic for the Customer Statement Processor
 * 
 * @author Yuvaraj Krishnamoorthy
 *
 */
@Component
public class StatementValidator {

	
	Logger logger = LoggerFactory.getLogger(StatementValidator.class);

	@Autowired
	RaboResponseBuilder raboResponseBuilder;


	/**
	 * Method to find the Duplicate Reference numbers in the Customer Statements
	 * 
	 * @param transactionList
	 * @return List of Records which have Duplicate Reference number in the list
	 */
	public List<Record> findDuplicateTransaction(@NotNull List<Record> transactionList) {
		
		logger.info(" findDuplicateTransaction() Method Entry");

		List<Record> duplicateTransactions = transactionList.stream()
				.collect(Collectors.groupingBy(Record::getReference)).entrySet().stream()
				.filter(e -> e.getValue().size() > 1).flatMap(e -> e.getValue().stream()).collect(Collectors.toList());

		logger.debug(" findDuplicateTransaction() Duplicate Records:"+duplicateTransactions);
		
		logger.info(" findDuplicateTransaction() Method Exist");
		return duplicateTransactions;
	}
	
	

	/**
	 * Method to validate the End balance and if its not matched then considering it
	 * as inValid
	 * 
	 * @param transactionList
	 * @return inValid Balance Records
	 */
	public List<Record> findInvalidBalance(@NotNull List<Record> transactionList) {
		
		logger.info(" findInvalidBalance() Method Entry");
		List<Record> invalidBals = transactionList.stream()
				.filter(s -> (s.getStartBalance().add(s.getMutation()))
						.compareTo(s.getEndBalance()) != 0)
				.collect(Collectors.toList());
		logger.debug(" findDuplicateTransaction() Invalid End Balance Records:"+invalidBals);
		
		logger.info(" findInvalidBalance() Method Exist");
		return invalidBals;
	}
	
	
	public List<RaboResponse> customerStatementProcessing(@NotEmpty List<Record> transactionList) {
		logger.info(" customerStatementProcessing() Method Entry");
		
		List<RaboResponse> records = raboResponseBuilder.getDuplicateRaboResponse(findDuplicateTransaction(transactionList));

		records.addAll(raboResponseBuilder.getInvalidBalanceRaboResponse(findInvalidBalance(transactionList)));
		
		logger.debug(" customerStatementProcessing() Invalid End Balance Records:"+records);
		
		logger.info(" customerStatementProcessing() Method Exist");
		return records;
		
	}
}
