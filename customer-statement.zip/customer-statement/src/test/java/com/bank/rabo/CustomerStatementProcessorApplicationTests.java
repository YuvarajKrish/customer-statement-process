package com.bank.rabo;

import javafx.application.Application;
import org.junit.Assert;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import static org.mockito.Mockito.doNothing;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = CustomerStatementProcessorApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class CustomerStatementProcessorApplicationTests {

    @Mock
    CustomerStatementProcessorApplication customerStatementProcessorApplication;

    @Test
    void contextLoads() {
    }

    @Test
    public void main() {
        //CustomerStatementProcessorApplication.main(new String[] {});
    }

    @Test
    public void xmlProcess() {
        customerStatementProcessorApplication.getXmlProcessor();
    }

    @Test
    public void csvProcess() {
        customerStatementProcessorApplication.getCsvProcessor();
    }

    @Test
    public void statementValidator() {
        customerStatementProcessorApplication.getStatementValidator();
    }

    @Test
    public void raboResponse() {
        customerStatementProcessorApplication.getRaboResponseBuilder();
    }

    @Test
    public void getMappingStrategy() {
        customerStatementProcessorApplication.getMappingStrategyMap();
    }

    @Test
    public void scvBean() {
        customerStatementProcessorApplication.getCsvBean();
    }

    @Test
    public void recordValid() {
        customerStatementProcessorApplication.getRecordValidator();
    }
}
