package com.bank.rabo.controller;

import com.bank.rabo.delegate.StatementProcessDelegation;
import com.bank.rabo.models.RaboResponse;
import com.bank.rabo.models.Record;
import org.apache.tomcat.util.http.fileupload.FileItem;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.multipart.MultipartFile;
import static org.mockito.ArgumentMatchers.any;
import static org.assertj.core.api.Assertions.assertThat;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;


@RunWith(SpringRunner.class)
@SpringBootTest
class StatementProcessorControllerTest {

    @InjectMocks
    StatementProcessorController controller;

    @Mock
    StatementProcessDelegation delegation;

    @Test
    void processMultiFileRequest() throws IOException {

        MultipartFile[] multipartFile = new MultipartFile[0];
        List<RaboResponse> listRabo = new ArrayList<>();
        RaboResponse response = new RaboResponse(new Record(),"Error");
        byte[] content = null;
        when(delegation.processMultiFile(any(MultipartFile.class))).thenReturn(listRabo);
        ResponseEntity<List<RaboResponse>> entity = controller.processMultiFileRequest(multipartFile);
        assertThat(entity.getStatusCodeValue()).isEqualTo(200);

    }
}