package com.bank.rabo.delegate;

import com.bank.rabo.exception.InvalidFileStructure;
import com.bank.rabo.models.RaboResponse;
import com.bank.rabo.service.CustomerStatementService;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@RunWith(SpringRunner.class)
@SpringBootTest
class StatementProcessDelegationTest {

    @InjectMocks
    StatementProcessDelegation delegation;

    @Mock
    CustomerStatementService service;

    @Test
    void processMultiFile_Exceptions() throws IOException {

        try {
            List<RaboResponse> response = new ArrayList<>();
            MultipartFile multipartFile = mock(MultipartFile.class);
            service = mock(CustomerStatementService.class);
            StatementProcessDelegation mockDelete = new StatementProcessDelegation();
            File file = new File("dummy");
            byte[] content = null;

            when(multipartFile.getOriginalFilename()).thenReturn("record.xml");
            when(multipartFile.getBytes()).thenReturn("Dummy String to test".getBytes());
            when(service.processFile(any(File.class))).thenReturn(response);
            List<RaboResponse> listRes = delegation.processMultiFile(multipartFile);
            assertEquals(response.size(), listRes.size());
        } catch (InvalidFileStructure e) {
            assertEquals(null, e.getMessage());
        }
    }


    @Test
    void processMultiFile() throws IOException {

        try {
            List<RaboResponse> response = new ArrayList<>();
            MultipartFile multipartFile = mock(MultipartFile.class);
            service = mock(CustomerStatementService.class);
            StatementProcessDelegation mockDelete = new StatementProcessDelegation();
            File file = new File("dummy");
            byte[] content = null;

            when(multipartFile.getOriginalFilename()).thenReturn("record.xml");
            when(service.processFile(any(File.class))).thenReturn(response);
            when(multipartFile.getBytes()).thenReturn("Dummy String to test".getBytes());
            List<RaboResponse> listRes = delegation.processMultiFile(multipartFile);
            assertEquals(response.size(), listRes.size());
        } catch (InvalidFileStructure e) {
            assertEquals(null, e.getMessage());
        }


    }
}