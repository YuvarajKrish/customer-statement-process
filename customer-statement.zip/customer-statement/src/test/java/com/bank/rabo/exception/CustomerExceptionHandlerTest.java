package com.bank.rabo.exception;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.context.request.WebRequest;

import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;


@RunWith(SpringRunner.class)
@SpringBootTest
public class CustomerExceptionHandlerTest {

    @InjectMocks
    CustomerExceptionHandler customerExceptionHandler;

    @Mock
    MethodArgumentNotValidException ex;
    @Mock
    WebRequest request;
    @Mock
    HttpHeaders headers;

    @Test
    public void handleInvalidRecord() {

        RecordNotValid recordNotValid = new RecordNotValid("message");
        ResponseEntity<Object> objectResponseEntity = customerExceptionHandler.handleInvalidRecordException(recordNotValid, request);
        assertThat(objectResponseEntity.getStatusCodeValue()).isEqualTo(400);
    }

    @Test
    public void handleInvalidFile() {

        InvalidFile recordNotValid = new InvalidFile("message");
        ResponseEntity<Object> objectResponseEntity = customerExceptionHandler.handleInvalidFileRequestException(recordNotValid, request);
        assertThat(objectResponseEntity.getStatusCodeValue()).isEqualTo(403);
    }


    public void handleMethodArgNotValid() {

        BindingResult bindingResult = mock(BindingResult.class);
        HttpStatus status = HttpStatus.CREATED;
        List<FieldError> fieldErrorList = new ArrayList<>();

        when(bindingResult.getFieldErrors()).thenReturn(fieldErrorList);

        ResponseEntity<Object> objectResponseEntity = customerExceptionHandler.handleMethodArgumentNotValid(ex, headers, status, request);
        assertThat(objectResponseEntity.getStatusCodeValue()).isEqualTo(400);
    }
}
