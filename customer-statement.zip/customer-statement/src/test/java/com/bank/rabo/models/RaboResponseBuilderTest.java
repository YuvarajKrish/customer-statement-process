package com.bank.rabo.models;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@RunWith(SpringRunner.class)
@SpringBootTest
class RaboResponseBuilderTest {

    @InjectMocks
    RaboResponseBuilder raboResponseBuilder;

    List<Record> transactionList;

    @BeforeEach
    public void dataProvider()
    {
        transactionList = new ArrayList<>();
        Record record1 = new Record();
        record1.setReference(12345);
        record1.setMutation(BigDecimal.ZERO);
        record1.setStartBalance(BigDecimal.TEN);
        record1.setEndBalance(BigDecimal.ONE);
        record1.setAccountNumber("ABI123455");
        record1.setDescription("Transaction");
        Record record2 = record1;
        transactionList.add(record1);
        transactionList.add(record2);
    }
    @Test
    void getDuplicateRaboResponse() {
        List<RaboResponse> list = raboResponseBuilder.getDuplicateRaboResponse(transactionList);
        assertEquals(2,list.size());
    }

    @Test
    void getInvalidBalanceRaboResponse() {
        List<RaboResponse> list = raboResponseBuilder.getInvalidBalanceRaboResponse(transactionList);
        assertEquals(2,list.size());
    }
}