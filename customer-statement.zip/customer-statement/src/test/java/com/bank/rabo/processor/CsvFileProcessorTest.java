package com.bank.rabo.processor;

import com.bank.rabo.models.Record;
import com.opencsv.bean.CsvToBean;
import com.opencsv.bean.HeaderColumnNameTranslateMappingStrategy;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@RunWith(SpringRunner.class)
@SpringBootTest
public class CsvFileProcessorTest {

    @InjectMocks
    CsvFileProcessor csvFileProcessor;

    @Mock
    CsvToBean csvToBean;

    @Mock
    HeaderColumnNameTranslateMappingStrategy<Record> strategy;

    @Test
    public void processFile() {

        File file = new File("..\\customer-statement\\records.csv");
        List<Record> list = new ArrayList<>();
        strategy = mock(HeaderColumnNameTranslateMappingStrategy.class);
        csvToBean = mock(CsvToBean.class);

        when(csvToBean.parse()).thenReturn(list);
        List<Record> resultList = csvFileProcessor.processFile(file);
        assertEquals(list.size(), resultList.size());

    }

    @Test
    public void processFile_Exception() {

        try {
            File file = new File("..\\customer-statement\\records.csv");
            List<Record> list = new ArrayList<>();

            csvToBean = mock(CsvToBean.class);

            when(csvToBean.parse()).thenReturn(list);
            List<Record> resultList = csvFileProcessor.processFile(file);
            assertEquals(list.size(), resultList.size());
        }catch (Exception e)
        {
            assertEquals(null , e.getMessage());
        }



    }


}
