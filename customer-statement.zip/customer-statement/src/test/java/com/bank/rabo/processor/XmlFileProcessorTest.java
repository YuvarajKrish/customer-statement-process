package com.bank.rabo.processor;

import com.bank.rabo.exception.InvalidFileStructure;
import com.bank.rabo.models.Record;
import com.bank.rabo.models.Records;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@RunWith(SpringRunner.class)
@SpringBootTest
class XmlFileProcessorTest {

    @InjectMocks
    XmlFileProcessor xmlFileProcessor;

    @Mock
    Unmarshaller jaxbUnmarshaller;

    @Test
    void processFile_FileError() throws JAXBException {

        File liveFile = new File("records.xml");
        List<Record> recordList = new ArrayList<>();
        Records records = new Records();
        Records mockRecords = mock(Records.class);
        jaxbUnmarshaller = mock(Unmarshaller.class);

        try {
            when(mockRecords.getRecord()).thenReturn(recordList);
            when(jaxbUnmarshaller.unmarshal(any(File.class))).thenReturn(records);
            List<Record> recordList1 = xmlFileProcessor.processFile(liveFile);
        } catch (InvalidFileStructure e) {
            assertEquals(null, e.getMessage());
        }
    }


}