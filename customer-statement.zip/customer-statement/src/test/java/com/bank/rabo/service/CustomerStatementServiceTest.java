package com.bank.rabo.service;

import com.bank.rabo.controller.CustomerStatementConstants;
import com.bank.rabo.exception.InvalidFileStructure;
import com.bank.rabo.models.RaboResponse;
import com.bank.rabo.models.Record;
import com.bank.rabo.processor.CsvFileProcessor;
import com.bank.rabo.processor.XmlFileProcessor;
import com.bank.rabo.validator.RecordValidator;
import com.bank.rabo.validator.StatementValidator;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@RunWith(SpringRunner.class)
@SpringBootTest
class CustomerStatementServiceTest {

    @InjectMocks
    CustomerStatementService customerStatementService;

    @Mock
    CsvFileProcessor csvFileProcessor;

    @Mock
    XmlFileProcessor xmlFileProcessor;

    @Mock
    StatementValidator statementValidator;

    @Mock
    RecordValidator recordValidator;

    @Test
    void processXMlFile() {

        File processFile = new File("records.xml");
        xmlFileProcessor = mock(XmlFileProcessor.class);
        List<Record> recordList = new ArrayList<>();
        File mfile = mock(File.class);
        when(mfile.getName()).thenReturn("records.xml");
        //when(mfile.getName().contains(CustomerStatementConstants.XML_FILE)).thenReturn(true);
        when(xmlFileProcessor.processFile(any(File.class))).thenReturn(recordList);
        List<RaboResponse> listRes = customerStatementService.processFile(processFile);
        assertEquals(0, listRes.size());

    }

    @Test
    void processCsvFile() {

        File processFile = new File("records.csv");
        xmlFileProcessor = mock(XmlFileProcessor.class);
        List<Record> recordList = new ArrayList<>();
        File mfile = mock(File.class);
        when(mfile.getName()).thenReturn("records.csv");
        //when(mfile.getName().contains(CustomerStatementConstants.XML_FILE)).thenReturn(true);
        when(xmlFileProcessor.processFile(any(File.class))).thenReturn(recordList);
        List<RaboResponse> listRes = customerStatementService.processFile(processFile);
        assertEquals(0, listRes.size());

    }

    @Test
    void processExceptionFile() {

        try {
            File processFile = new File("records.txt");
            xmlFileProcessor = mock(XmlFileProcessor.class);
            List<Record> recordList = new ArrayList<>();
            File mfile = mock(File.class);
            when(mfile.getName()).thenReturn("records.txt");
            //when(mfile.getName().contains(CustomerStatementConstants.XML_FILE)).thenReturn(true);
            when(xmlFileProcessor.processFile(any(File.class))).thenReturn(recordList);
            List<RaboResponse> listRes = customerStatementService.processFile(processFile);
            assertEquals(0, listRes.size());
        } catch (InvalidFileStructure e) {
            assertEquals(null, e.getMessage());
        }

    }
}