package com.bank.rabo.validator;

import com.bank.rabo.exception.RecordNotValid;
import com.bank.rabo.models.Record;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;

@RunWith(SpringRunner.class)
@SpringBootTest
class RecordValidatorTest {

    @InjectMocks
    RecordValidator validator;

    Record record;

    @BeforeEach
    public void setRecord()
    {
        record = new Record();
        record.setAccountNumber("SBI12345NDG");
        record.setDescription("Bank Transactions");
        record.setEndBalance(BigDecimal.TEN);
        record.setMutation(BigDecimal.ONE);
        record.setStartBalance(BigDecimal.TEN);
        record.setReference(12345);

        validator = mock(validator.getClass());
        validator = new RecordValidator();
        //myObjectImplImpl = new MyObjectImplImpl();
        //Set the private variable values here by reflection.
        ReflectionTestUtils.setField(validator, "invalidMutation", "null");
        ReflectionTestUtils.setField(validator, "refNotAccNt", "null");
        ReflectionTestUtils.setField(validator, "refNotValid", "null");

    }

    @Test
    void validateRecord() {
        assertTrue(validator.validateRecord(record));
        assertEquals(LoggerFactory.getLogger(RecordValidator.class),validator.logger);
        assertEquals("null",validator.invalidMutation);
        assertEquals("null",validator.refNotAccNt);
        assertEquals("null",validator.refNotValid);
    }


    @Test
    void validateAccountNumberIn_Record() {

        try{
            record.setAccountNumber("");
            assertTrue(validator.validateRecord(record));
        }catch (RecordNotValid e)
        {
            String message = "null12345";
            assertEquals(message, e.getMessage());
        }

    }

    @Test
    void validateMutationIn_Record() {

        try{
            record.setMutation(BigDecimal.ZERO);
            assertTrue(validator.validateRecord(record));
        }catch (RecordNotValid e)
        {
            String message = "null12345";
            assertEquals(message, e.getMessage());
        }

    }

    @Test
    void validateReferIn_Record() {

        try{
            record.setReference(0);
            assertTrue(validator.validateRecord(record));
        }catch (RecordNotValid e)
        {
            String message = "null0";
            assertEquals(message, e.getMessage());
        }

    }
}